package com.hdfcbank.smartwealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgPoolDbApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(PgPoolDbApplication.class, args);
	}

}
