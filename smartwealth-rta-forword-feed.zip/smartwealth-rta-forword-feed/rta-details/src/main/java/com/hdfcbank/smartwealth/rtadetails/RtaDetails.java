/**
 * 
 */
package com.hdfcbank.smartwealth.rtadetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Dell
 *
 */
@SpringBootApplication
public class RtaDetails {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(RtaDetails.class, args);

	}

}
